/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author Rima Regiani
 */

public class koneksi {
    public static java.sql.Connection koneksi;
    
    public static java.sql.Connection getKoneksi(){
     try{
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection("jdbc:mysql://localhost/db_elektronik","root", "");
        }catch(ClassNotFoundException | SQLException e){
            System.out.println(e.getMessage());
        }
        return koneksi;    
    }

    public static Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
} 
